public class MicrophoneUtils {

    private void listenMicrophone(){
        Byte[] buff;
    }
}
